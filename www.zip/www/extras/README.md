Shared libraries
==================

### PDFJS (./pdfjs/*)

https://mozilla.github.io/pdf.js/

Apache License

### PDFJs (./pdfjs.js)

https://github.com/rkusa/pdfjs

MIT License


### js-xlsx

https://github.com/SheetJS/js-xlsx

Microsoft Open Specifications Promise
Apache License



### HTML2Canvas

https://html2canvas.hertzen.com/

MIT License



### PTSans Font

http://www.paratype.com/public/

ParaType Free Font License
